import React from 'react';

function ArhMemPage() {
  return (
    <div>
      <h1> ... Architecture and MCU MEMORY (KB) ... </h1>
      <h3> >>> Architecture: AVR (8 Bit). </h3>
      <h4> >>> MCU Memory : 32 KB of Flash / 2KB of Static RAM. </h4>
     </div>
  );
}

export default ArhMemPage;
